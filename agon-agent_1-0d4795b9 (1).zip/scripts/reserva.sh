#!/bin/bash
# Arena Manager - Reserva Simples via Bash
# Uso: ./scripts/reserva.sh [dia] [hora]

DIA="${1:-Ter}"
HORA="${2:-18:00}"
QUADRA="${3:-A}"

WHATSAPP="https://wa.me/5586994733462?text=Quero+reservar+Quadra+${QUADRA}+${DIA}+as+${HORA}"

PIX_MENSAGEM="Reserva: Quadra ${QUADRA} | ${DIA} ${HORA} | Pix: R\$ 120,00 | Chave Pix: 06164531322"

echo "========================================"
echo "  ARENA MANAGER - RESERVA SIMPLES"
echo "========================================"
echo "  Dia:      ${DIA}"
echo "  Hora:     ${HORA}"
echo "  Quadra:   ${QUADRA}"
echo "  WhatsApp: ${WHATSAPP}"
echo "  PIX Msg:  ${PIX_MENSAGEM}"
echo "========================================"
echo "Abrindo WhatsApp..."
open "${WHATSAPP}" 2>/dev/null || xdg-open "${WHATSAPP}" 2>/dev/null || echo "Link: ${WHATSAPP}"
echo "Enviar QR Pix no WhatsApp para confirmar pagamento."
