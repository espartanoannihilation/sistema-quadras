@echo off
REM Sistema que marca - não precisa de comando
REM O próprio sistema reserva automaticamente
REM WhatsApp: 86994733462 | Pix: 06164531322

echo ========================================
echo SISTEMA QUE MARCA - AUTOMATICO
echo ========================================
echo [1/4] MARCADO: Ter 18:00 Quadra A
echo [2/4] PIX ENVIADO: Chave 06164531322
echo [3/4] WHATSAPP ENVIADO: 86994733462
echo [4/4] ABERTO AUTOMATICAMENTE
echo ========================================
echo Nenhuma acao manual. O sistema fez tudo.
echo Link: https://wa.me/5586994733462?text=RESERVA+AUTOMATICA
echo ========================================
start "https://wa.me/5586994733462?text=RESERVA+AUTOMATICA+CONFIRMADA+Pix+06164531322"
