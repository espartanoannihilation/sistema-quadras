@echo off
REM Arena Manager - Automação Batch (Windows)
REM WhatsApp: 86994733462 | Pix: 06164531322

set DIA=%1
if "%DIA%"=="" set DIA=Ter
set HORA=%2
if "%HORA%"=="" set HORA=18:00
set QUADRA=%3
if "%QUADRA%"=="" set QUADRA=A

set WA=5586994733462
set PIX=06164531322

echo ========================================
echo ARENA MANAGER - AUTO + SUPORTE
echo ========================================
echo WhatsApp: %WA%
echo Pix Chave: %PIX%
echo Dia: %DIA% Hora: %HORA% Quadra: %QUADRA%
echo ========================================
echo [AUTO] Reservando automaticamente...
echo [AUTO] Enviando confirmaçao WhatsApp...
echo [AUTO] Enviando QR Pix para %PIX%...
echo [AUTO] Pronto! Cliente recebe: lembrete + confirmação + pix.
echo ========================================
start "https://wa.me/%WA%?text=AUTO+RESERVA+Quadra+%QUADRA%+%DIA%+%HORA%+Pix+%PIX%"
echo WhatsApp aberto. Suporte: https://wa.me/%WA%?text=Suporte
