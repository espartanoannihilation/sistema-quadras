#!/usr/bin/env python3
"""
Arena Manager - Reserva via Python + WhatsApp + Pix
Uso: python3 scripts/reserva.py --dia Ter --hora 18:00 --quadra A
"""
import argparse, urllib.parse, webbrowser

parser = argparse.ArgumentParser(description="Reserva Arena Manager")
parser.add_argument("--dia", default="Ter")
parser.add_argument("--hora", default="18:00")
parser.add_argument("--quadra", default="A", choices=["A","B","C","D"])
args = parser.parse_args()

msg = f"Quero reservar Quadra {args.quadra} | {args.dia} às {args.hora} | Pix: R$ 120,00 | Chave Pix: 06164531322"
wa_link = f"https://wa.me/5586994733462?text={urllib.parse.quote(msg)}"
pix_text = f"Pagamento PIX para Arena Manager\nValor: R$ 120,00 | Chave Pix: 06164531322\nReferência: Quadra {args.quadra} {args.dia} {args.hora}"

print("="*40)
print("ARENA MANAGER - RESERVA PYTHON")
print("="*40)
print(f"Dia:      {args.dia}")
print(f"Hora:     {args.hora}")
print(f"Quadra:   {args.quadra}")
print(f"WhatsApp: {wa_link}")
print(f"Pix Msg:  {pix_text}")
print("="*40)
print("Abrindo WhatsApp...")
webbrowser.open(wa_link)
print("Envie o QR do Pix no chat para confirmar.")
