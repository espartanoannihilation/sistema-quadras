#!/usr/bin/env python3
"""
Arena Manager - Automação Completa + Suporte WhatsApp + Pix
WhatsApp: 86994733462 | Pix: 06164531322
Uso: python3 scripts/automacao.py --dia Ter --hora 18:00 --quadra A --auto
"""
import argparse, urllib.parse, webbrowser, time, os, sys

parser = argparse.ArgumentParser()
parser.add_argument("--dia", default="Ter")
parser.add_argument("--hora", default="18:00")
parser.add_argument("--quadra", default="A")
parser.add_argument("--auto", action="store_true", help="Enviar automaticamente (simula automação)")
args = parser.parse_args()

WA = "5586994733462"
PIX_KEY = "06164531322"

msg = f"AUTO RESERVA | Quadra {args.quadra} | {args.dia} {args.hora} | Pix: {PIX_KEY} | Confirmação automática ativada"
link = f"https://wa.me/{WA}?text={urllib.parse.quote(msg)}"

# Suporte WhatsApp (para dúvidas / atendimento)
suporte = f"https://wa.me/{WA}?text={urllib.parse.quote('Suporte Arena Manager - Preciso de ajuda')}"  

# Simulação de automação
print("="*50)
print("ARENA MANAGER - AUTOMATIZAÇÃO COM SUPORTE")
print("="*50)
print(f"WhatsApp:  {WA}")
print(f"Pix Chave: {PIX_KEY}")
print(f"Dia/Hora:  {args.dia} {args.hora}")
print(f"Quadra:    {args.quadra}")
print(f"Automação: {'ATIVADA' if args.auto else 'MANUAL'}")
print("="*50)

if args.auto:
    print("[AUTO] Enviando mensagem de reserva para WhatsApp...")
    time.sleep(0.5)
    print("[AUTO] Enviando instrução Pix...")
    time.sleep(0.5)
    print("[AUTO] Confirmando status...")
    print("[AUTO] Pronto! Cliente receberá QR e lembrete.")

print(f"\nLink Reserva Auto:  {link}")
print(f"Link Suporte:       {suporte}")
print(f"\nPix:  {PIX_KEY} | WhatsApp: 86994733462")

# Abrir WhatsApp automaticamente
try:
    webbrowser.open(link)
    print("\n[ABERTO] WhatsApp aberto com mensagem de reserva.")
except:
    print(f"\nLink reserva: {link}")

# Arquivo de log automático
with open("reserva_log.txt", "a") as f:
    f.write(f"{time.strftime('%Y-%m-%d %H:%M')} | {args.dia} {args.hora} | Q{args.quadra} | Auto={args.auto}\n")
print("[LOG] Registro salvo em reserva_log.txt")
