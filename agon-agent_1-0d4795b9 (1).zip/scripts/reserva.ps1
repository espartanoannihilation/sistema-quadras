# Arena Manager - Reserva PowerShell
# Uso: .\scripts\reserva.ps1 -Dia "Ter" -Hora "18:00" -Quadra "A"
param(
    [string]$Dia="Ter",
    [string]$Hora="18:00",
    [string]$Quadra="A"
)
$msg = "Quero reservar Quadra $Quadra | $Dia às $Hora | Pix: R$ 120,00 | Chave Pix: 06164531322"
$wa = "https://wa.me/5586994733462?text=" + [System.Web.HttpUtility]::UrlEncode($msg)
$ptext = "Pagamento PIX`nValor: R$ 120,00 | Chave Pix: 06164531322`nReferencia: Quadra $Quadra $Dia $Hora"
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  ARENA MANAGER - RESERVA POWERSHELL" -ForegroundColor Cyan
Write-Host "========================================"
Write-Host "  Dia:      $Dia"
Write-Host "  Hora:     $Hora"
Write-Host "  Quadra:   $Quadra"
Write-Host "  WhatsApp: $wa"
Write-Host "  Pix:      $ptext"
Write-Host "========================================"
Start-Process $wa
Write-Host "Abrido no WhatsApp. Envie o QR Pix para confirmar."
