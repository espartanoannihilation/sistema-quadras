import { Footprints, CreditCard, MessageCircle, CalendarDays, Phone } from 'lucide-react';

const steps = [
  { num: '01', icon: Footprints, title: 'Escolha a quadra', desc: 'Filtre por esporte, horário e localização.' },
  { num: '02', icon: CalendarDays, title: 'Selecione o horário', desc: 'Horários livres em tempo real, sem espera.' },
  { num: '03', icon: CreditCard, title: 'Pague via PIX', desc: 'Confirmação instantânea e segura.' },
  { num: '04', icon: MessageCircle, title: 'Receba no WhatsApp', desc: 'Lembretes e confirmações automáticas.' },
];

export default function ComoFunciona() {
  return (
    <section id="como-funciona" className="bg-white py-24 lg:py-32">
      <div className="mx-auto max-w-6xl px-6 lg:px-10">
        <div className="max-w-2xl mb-16">
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-graphite tracking-[-0.03em] mb-4">Como funciona</h2>
          <p className="font-sans text-ink/60 text-lg leading-relaxed">Quatro passos simples para garantir sua quadra e começar a jogar.</p>
        </div>
        <div className="flex justify-center mt-10">
          <a href="https://wa.me/5586994733462?text=Reserva+automatica:+Quero+reservar+em+{dia}+{hora}" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 font-display font-medium text-graphite bg-amber px-8 py-3.5 rounded-full hover:bg-amber-soft transition-all shadow-lg shadow-amber/25">Sistema que marca → WhatsApp <Phone size={18} /></a>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((s) => (
            <article key={s.num} className="group bg-surface border border-slate-100 rounded-3xl p-8 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
              <div className="flex items-center gap-3 mb-6">
                <span className="font-display text-4xl font-bold text-slate-200 group-hover:text-amber/30 transition-colors">{s.num}</span>
                <div className="w-10 h-10 rounded-xl bg-amber/10 text-amber flex items-center justify-center"><s.icon size={20} strokeWidth={1.5} /></div>
              </div>
              <h3 className="font-display text-xl font-semibold text-graphite mb-2">{s.title}</h3>
              <p className="font-sans text-sm text-ink/60 leading-relaxed">{s.desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
