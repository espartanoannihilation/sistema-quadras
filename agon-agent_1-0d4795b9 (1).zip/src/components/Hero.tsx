import { ArrowDown, ShieldCheck, Clock, CheckCircle2, Phone } from 'lucide-react';

export default function Hero() {
  return (
    <section id="inicio" className="relative min-h-[92vh] flex items-center overflow-hidden">
      {/* Beautiful background image */}
      <div className="absolute inset-0 z-0">
        <img src="/bg-hero.jpg" alt="" className="w-full h-full object-cover opacity-60" />
        <div className="absolute inset-0 bg-gradient-to-b from-graphite/70 via-graphite/50 to-graphite/80" />
      </div>

      <div className="relative z-10 mx-auto max-w-6xl px-6 lg:px-10 pt-28 pb-20 w-full">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-white/10 text-amber border border-white/15 rounded-full px-4 py-1.5 text-xs font-display font-semibold tracking-wide mb-6 backdrop-blur-sm">
            <Clock size={14} /> Reserva em menos de 2 minutos
          </div>
          <h1 className="font-display text-[clamp(3rem,7vw,6rem)] leading-[0.92] font-bold tracking-[-0.04em] text-white mb-6 drop-shadow-lg">
            Reserve sua quadra de <br />
            <span className="text-amber">futebol, vôlei</span> e beach tennis.
          </h1>
          <p className="font-sans text-lg lg:text-xl text-white/80 leading-relaxed max-w-2xl mb-10">
            Pagamento via PIX, confirmação instantânea e lembretes no WhatsApp. A melhor arena esportiva da região, agora totalmente automática.
          </p>
          <div className="flex flex-wrap gap-3">
            <a href="https://wa.me/5586994733462?text=RESERVA+AUTOMATICA+CONFIRMADA+Pix+06164531322" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2.5 px-7 py-3.5 bg-amber text-graphite font-display font-semibold rounded-full hover:bg-amber-soft transition-all shadow-xl shadow-amber/20 text-sm tracking-tight">
              Reservar Auto <Phone size={16} />
            </a>
            <a href="#quadras" className="inline-flex items-center gap-2.5 px-7 py-3.5 bg-white/10 text-white font-display font-medium rounded-full hover:bg-white/20 border border-white/15 transition-all text-sm">
              Ver quadras <ArrowDown size={16} />
            </a>
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-4 mt-14">
          {[
            { title: 'Pagamento via PIX', desc: 'Chave: 06164531322', icon: CheckCircle2 },
            { title: 'Lembretes automáticos', desc: 'WhatsApp 86994733462', icon: Clock },
            { title: 'Cancelamento fácil', desc: 'Até 12h antes sem taxa', icon: ShieldCheck },
          ].map((item) => (
            <div key={item.title} className="bg-white/[0.08] border border-white/[0.12] rounded-2xl p-6 backdrop-blur-sm hover:bg-white/[0.12] transition-colors">
              <div className="w-10 h-10 rounded-xl bg-amber/20 text-amber flex items-center justify-center mb-3"><item.icon size={20} strokeWidth={1.5} /></div>
              <h3 className="font-display font-semibold text-white text-base mb-1">{item.title}</h3>
              <p className="font-sans text-sm text-white/60">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
