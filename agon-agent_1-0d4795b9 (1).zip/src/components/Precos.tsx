import { Check } from 'lucide-react';

const plans = [
  { name: 'Horário Único', price: 'R$ 85 — R$ 145', period: 'Por hora de uso', features: ['Reserva imediata', 'Pago via PIX', 'Cancele até 12h antes'], highlight: false },
  { name: 'Pacote Mensal', price: 'R$ 890', period: '4 horas por semana', features: ['Horários fixos', 'Prioridade de reserva', 'Lembretes no WhatsApp', 'Relatório mensal'], highlight: true },
  { name: 'Clube Corporativo', price: 'Sob medida', period: 'Por demanda', features: ['Quadras exclusivas', 'Arbitragem inclusa', 'Área de convivência', 'Suporte dedicado'], highlight: false },
];

export default function Precos() {
  return (
    <section id="precos" className="bg-white py-24 lg:py-32">
      <div className="mx-auto max-w-6xl px-6 lg:px-10">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-graphite tracking-[-0.03em] mb-4">Preços simples</h2>
          <p className="font-sans text-ink/60 text-lg">Sem taxas ocultas. Reserva agora e comece a jogar.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {plans.map((p) => (
            <article key={p.name} className={`relative rounded-3xl p-8 lg:p-10 transition-all duration-300 ${p.highlight ? 'bg-graphite text-white shadow-2xl shadow-graphite/20 scale-[1.02]' : 'bg-surface border border-slate-100 text-graphite hover:-translate-y-1 hover:shadow-xl'}`}>
              {p.highlight && <span className="absolute -top-3 left-8 bg-amber text-graphite text-[11px] font-display font-bold px-3 py-1 rounded-full">Mais escolhido</span>}
              <h3 className="font-display text-xl font-semibold mb-2">{p.name}</h3>
              <p className="font-sans text-sm text-ink/50 mb-4">{p.period}</p>
              <p className={`font-display text-4xl font-bold tracking-tight mb-6 ${p.highlight ? 'text-amber' : 'text-graphite'}`}>{p.price}</p>
              <ul className="space-y-3 mb-8">
                {p.features.map(f => (
                  <li key={f} className={`flex items-center gap-3 text-sm font-sans ${p.highlight ? 'text-slate-200' : 'text-ink/70'}`}>
                    <Check size={16} className={p.highlight ? 'text-amber' : 'text-emerald'} strokeWidth={2.5} /> {f}
                  </li>
                ))}
              </ul>
              <a href="https://wa.me/5586994733462" target="_blank" rel="noopener noreferrer" className={`block text-center font-display font-medium rounded-full py-3.5 transition-colors ${p.highlight ? 'bg-amber text-graphite hover:bg-amber-soft' : 'bg-graphite text-white hover:bg-ink'}`}>Solicitar via WhatsApp</a>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
