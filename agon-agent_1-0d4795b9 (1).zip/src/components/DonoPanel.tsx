import { Shield, EyeOff, FileCheck, Lock } from 'lucide-react';
import { DADOS_ESPACO } from '../lib/space';

export default function DonoPanel() {
  const reservas = [
    { nome: "João Silva", telefone: "(86) 99999-1111", modalidade: "Beach Tennis", quadra: "Quadra 1", data: "25/07", inicio: "18:00", fim: "19:00", status: "Confirmada", valor: "R$ 120,00" },
    { nome: "Maria Oliveira", telefone: "(86) 98888-2222", modalidade: "Vôlei", quadra: "Quadra 3", data: "26/07", inicio: "19:00", fim: "20:00", status: "Confirmada", valor: "R$ 85,00" },
    { nome: "Carlos Lima", telefone: "(86) 97777-3333", modalidade: "Vôlei", quadra: "Quadra 4", data: "25/07", inicio: "12:00", fim: "13:00", status: "Reagendada", valor: "R$ 65,00" },
  ];

  return (
    <section id="dono" className="relative bg-ink text-parchment py-24 lg:py-32 overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-parchment/20 to-transparent" />
      <div className="mx-auto max-w-[1200px] px-6 lg:px-10">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 bg-parchment/10 text-parchment border border-parchment/20 rounded-full px-3 py-1 text-[11px] font-display font-semibold tracking-widest uppercase mb-4">
              <Lock size={12} /> Acesso Restrito — Só o Dono
            </div>
            <h2 className="font-display text-[clamp(2.2rem,7vw,4rem)] leading-[0.92] tracking-[-0.03em]">Painel do Dono</h2>
            <p className="font-sans text-parchment/50 text-base mt-3">Ficha completa de reservas. Dados do cliente visíveis apenas aqui.</p>
          </div>
          <div className="flex items-center gap-2 text-parchment/40 text-sm font-sans"><EyeOff size={16}/> Visitantes não veem esta seção</div>
        </div>

        <div className="grid lg:grid-cols-12 gap-8">
          {/* Ficha de reservas */}
          <div className="lg:col-span-8">
            <div className="bg-white/[0.05] border border-parchment/[0.08] rounded-3xl p-6 lg:p-8 backdrop-blur-md">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-amber/15 text-amber flex items-center justify-center"><FileCheck size={20} strokeWidth={1.5}/></div>
                <h3 className="font-display text-xl font-medium">Ficha de Reservas Ativas</h3>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm font-sans">
                  <thead>
                    <tr className="border-b border-parchment/10 text-parchment/40 text-xs uppercase tracking-widest">
                      <th className="text-left py-3 font-display">Cliente</th>
                      <th className="text-left py-3 font-display">Telefone</th>
                      <th className="text-left py-3 font-display">Modalidade</th>
                      <th className="text-left py-3 font-display">Quadra</th>
                      <th className="text-left py-3 font-display">Data</th>
                      <th className="text-left py-3 font-display">Horário</th>
                      <th className="text-left py-3 font-display">Status</th>
                      <th className="text-right py-3 font-display">Valor</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reservas.map((r, i) => (
                      <tr key={i} className="border-b border-parchment/5 hover:bg-white/5 transition-colors">
                        <td className="py-3 font-medium text-parchment">{r.nome}</td>
                        <td className="py-3 text-parchment/60">{r.telefone}</td>
                        <td className="py-3 text-parchment/60">{r.modalidade}</td>
                        <td className="py-3 text-parchment/60">{r.quadra}</td>
                        <td className="py-3 text-parchment">{r.data}</td>
                        <td className="py-3 text-parchment/70">{r.inicio} — {r.fim}</td>
                        <td className="py-3"><span className={`px-2 py-0.5 rounded-full text-[10px] font-display font-bold uppercase ${r.status === 'Confirmada' ? 'bg-emerald/20 text-emerald' : 'bg-amber/20 text-amber'}`}>{r.status}</span></td>
                        <td className="py-3 text-right font-medium text-amber">{r.valor}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-6 flex gap-3 flex-wrap text-xs font-sans text-parchment/50">
                <span className="bg-parchment/10 px-3 py-1 rounded-full">Total confirmadas: 2</span>
                <span className="bg-parchment/10 px-3 py-1 rounded-full">Reagendada: 1</span>
                <span className="bg-parchment/10 px-3 py-1 rounded-full">Pizza de ocupação: 75%</span>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            <div className="bg-white/[0.05] border border-parchment/[0.08] rounded-3xl p-6 backdrop-blur-md">
              <h3 className="font-display text-xl font-medium mb-4 flex items-center gap-2"><Shield size={18} className="text-amber"/> Regras do Espaço</h3>
              <ul className="space-y-2 text-sm font-sans text-parchment/70 leading-snug">
                {DADOS_ESPACO.regras.map((r, i) => <li key={i} className="flex gap-2"><span className="text-amber shrink-0">•</span> {r}</li>)}
              </ul>
            </div>

            <div className="bg-amber/10 border border-amber/20 rounded-3xl p-6 backdrop-blur-md">
              <h3 className="font-display text-xl font-medium mb-3 text-amber">WhatsApp do Dono</h3>
              <p className="font-sans text-parchment/90 text-sm mb-3">Receba as reservas diretamente no seu celular. Nenhum dado fica exposto publicamente.</p>
              <a href="https://wa.me/5586994733462?text=CONFIRMAR+RESERVA+ARENA+SPORT+TERESINA" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 bg-amber text-graphite font-display font-semibold px-5 py-3 rounded-full hover:bg-amber-soft transition-colors text-sm">Acessar WhatsApp →</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
