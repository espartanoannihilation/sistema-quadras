import { useState, useMemo } from 'react';
import { CheckCircle2, XCircle, Clock, User, Phone, MapPin, CreditCard, ShieldAlert, Filter } from 'lucide-react';
import { reservasAtivas, reservasCanceladas, DADOS_ESPACO } from '../lib/space';

export default function AdminDashboard() {
  const [filter, setFilter] = useState<'todas' | 'ativas' | 'canceladas'>('todas');

  const todas = useMemo(() => {
    const ativas = reservasAtivas.map(r => ({ ...r, tipo: 'ativa' as const }));
    const cancel = reservasCanceladas.map(r => ({ ...r, tipo: 'cancelada' as const, motivo: r.motivoCancelamento }));
    return [...ativas, ...cancel];
  }, []);

  const filtradas = todas.filter(r => {
    if (filter === 'todas') return true;
    if (filter === 'ativas') return r.tipo === 'ativa';
    return r.tipo === 'cancelada';
  });

  const totalValor = todas.filter(r => r.tipo === 'ativa').reduce((s, r) => s + 85, 0); // estimado

  return (
    <section id="adm" className="relative bg-ink text-parchment py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '48px 48px' }} />

      <div className="relative mx-auto max-w-[1360px] px-6 lg:px-10">
        <div className="flex items-center gap-3 mb-4">
          <span className="px-2.5 py-1 bg-amber/15 text-amber rounded-full text-[11px] font-display font-bold tracking-wide">ADMINISTRATIVO</span>
          <span className="text-parchment/40 font-sans text-xs">Só o dono vê</span>
        </div>
        <h2 className="font-editorial text-[clamp(2.5rem,7vw,4.5rem)] leading-[0.95] tracking-[-0.03em] mb-4">Painel de <span className="italic font-normal text-parchment/60">controle.</span></h2>
        <p className="font-sans text-parchment/60 text-lg mb-12 max-w-2xl">Reserva, cancelamento, reagendamento e controle de quadras — tudo visível para o administrador.</p>

        {/* Stats */}
        <div className="grid sm:grid-cols-4 gap-4 lg:gap-6 mb-14">
          {[
            { label: 'Reservas ativas', value: String(reservasAtivas.length), icon: CheckCircle2 },
            { label: 'Canceladas', value: String(reservasCanceladas.length), icon: XCircle },
            { label: 'Valor estimado (R$)', value: totalValor.toFixed(2), icon: CreditCard },
            { label: 'Quadras', value: '4', icon: MapPin },
          ].map(s => (
            <div key={s.label} className="bg-parchment/[0.06] border border-parchment/10 rounded-2xl p-6 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-3"><s.icon size={20} className="text-amber" strokeWidth={1.5} /><span className="font-sans text-xs uppercase tracking-[0.15em] text-parchment/50">{s.label}</span></div>
              <p className="font-display text-3xl font-bold text-parchment">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Filters + Table */}
        <div className="flex flex-wrap gap-3 mb-6">
          {([['todas','Todas'],['ativas','Ativas'],['canceladas','Canceladas']] as const).map(([k,l]) => (
            <button key={k} onClick={() => setFilter(k)} className={`px-4 py-2 rounded-full text-sm font-display font-medium transition-colors ${filter===k ? 'bg-amber text-ink' : 'bg-parchment/10 text-parchment/60 hover:text-parchment'}`}>{l}</button>
          ))}
        </div>

        <div className="bg-parchment/[0.04] border border-parchment/10 rounded-3xl overflow-hidden backdrop-blur-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left font-sans text-sm">
              <thead className="bg-parchment/[0.08] text-parchment/70 uppercase text-[11px] tracking-widest font-display">
                <tr>
                  <th className="px-5 py-3">Cliente</th>
                  <th className="px-5 py-3">Modalidade</th>
                  <th className="px-5 py-3">Quadra</th>
                  <th className="px-5 py-3">Data / Hora</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3">Ação</th>
                </tr>
              </thead>
              <tbody>
                {filtradas.map((r, i) => (
                  <tr key={i} className="border-t border-parchment/10 hover:bg-parchment/[0.06] transition-colors">
                    <td className="px-5 py-3 font-medium text-parchment flex items-center gap-2"><User size={14} className="text-amber/60" /> {r.nome || '—'}</td>
                    <td className="px-5 py-3 text-parchment/80">{r.modalidade || '—'}</td>
                    <td className="px-5 py-3 text-parchment/80">{r.quadra || '—'}</td>
                    <td className="px-5 py-3 text-parchment/80"><Clock size={12} className="inline text-amber/60 mr-1"/>{r.data || '—'} {r.inicio || ''}</td>
                    <td className="px-5 py-3"><span className={`px-2 py-0.5 rounded-full text-[11px] font-display font-bold ${r.tipo==='ativa' ? 'bg-amber/20 text-amber' : 'bg-red-400/20 text-red-300'}`}>{r.tipo==='ativa'?'Confirmada':'Cancelada'}</span></td>
                    <td className="px-5 py-3"><button onClick={() => alert(`Detalhes: ${r.nome}\nTelefone: ${r.telefone}\nStatus: ${r.tipo}\n${r.motivoCancelamento ? 'Motivo: '+r.motivoCancelamento : ''}`)} className="text-xs bg-parchment/10 hover:bg-parchment/20 text-parchment px-3 py-1 rounded-full transition">Ver</button></td>
                  </tr>
                ))}
                {filtradas.length === 0 && (
                  <tr><td colSpan={6} className="px-5 py-8 text-center text-parchment/40 font-sans">Nenhuma matrícula neste filtro.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap gap-4 text-xs font-sans text-parchment/40">
          <span>WhastApp: 86994733462</span>
          <span>Pix: 06164531322</span>
          <span>Espaço: Arena Sport Teresina — Av. Joaquim Nabuco, 1450</span>
          <span>Horário atendimento humano: Seg a Sex 08h-18h | Sáb 09h-13h</span>
        </div>
      </div>
    </section>
  );
}
