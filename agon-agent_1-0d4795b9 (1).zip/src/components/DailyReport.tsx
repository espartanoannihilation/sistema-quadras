import { useState } from 'react';
import { Download, Mail, FileText, Clock, CheckCircle2, Shield } from 'lucide-react';
import { gerarRelatorioDiario, relatorioParaCSV } from '../lib/space';

export default function DailyReport() {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [sent, setSent] = useState(false);

  const rows = gerarRelatorioDiario(date);
  const total = rows.length;
  const valorTotal = rows.reduce((acc, r) => {
    const v = r.modalidade === 'beach tennis' ? 120 : 85;
    return acc + v;
  }, 0);

  const handleDownload = () => {
    const csv = relatorioParaCSV(date);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `relatorio_arena_${date}.csv`; document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
  };

  const handleSendEmail = () => {
    setSent(true);
    setTimeout(() => setSent(false), 5000);
  };

  return (
    <section id="relatorio" className="relative bg-gradient-to-b from-ink via-graphite to-ink text-parchment py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(212,168,67,0.5) 1px, transparent 0)', backgroundSize: '48px 48px' }} />
      <div className="mx-auto max-w-[1200px] px-6 lg:px-10 relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-14">
          <div className="lg:col-span-5">
            <h2 className="font-display text-[clamp(2.5rem,6vw,4rem)] leading-[0.92] font-bold tracking-[-0.03em] mb-4">Relatório diário<br /><span className="italic font-normal text-amber-soft">para o dono.</span></h2>
            <p className="font-sans text-parchment/60 text-lg leading-relaxed mb-6">Geração automática baseada nas reservas do dia. Dados de cliente, modalidade, quadra, horário e status — tudo visível para o dono do local.</p>
            <div className="flex items-center gap-3 text-sm font-sans text-amber-soft">
              <CheckCircle2 size={18} /> <span>Dados completos</span>
              <Shield size={18} /> <span>Nenhum dado oculto</span>
              <Clock size={18} /> <span>Atualiza automaticamente</span>
            </div>
          </div>

          <div className="lg:col-span-6 lg:col-start-7 bg-white/[0.06] border border-white/[0.1] rounded-[2rem] p-8 lg:p-10 backdrop-blur-md">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-xl font-semibold text-parchment">Relatório: {date}</h3>
              <input type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-white/10 border border-white/20 rounded-xl px-3 py-1.5 font-sans text-sm text-parchment focus:outline-none focus:border-amber/60" />
            </div>

            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="bg-white/[0.08] rounded-2xl p-4 text-center"><p className="font-display text-3xl font-bold text-amber">{total}</p><p className="font-sans text-xs text-parchment/50 mt-1">Reservas</p></div>
              <div className="bg-white/[0.08] rounded-2xl p-4 text-center"><p className="font-display text-3xl font-bold text-amber">R$ {valorTotal},00</p><p className="font-sans text-xs text-parchment/50 mt-1">Faturamento</p></div>
              <div className="bg-white/[0.08] rounded-2xl p-4 text-center"><p className="font-display text-3xl font-bold text-amber">4</p><p className="font-sans text-xs text-parchment/50 mt-1">Quadras</p></div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-sans text-sm">
                <thead>
                  <tr className="text-parchment/50 text-xs uppercase tracking-wider">
                    <th className="py-2">Nome</th><th>Telefone</th><th>Modalidade</th><th>Quadra</th><th>Horário</th><th>Status</th><th>Valor</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.length === 0 ? (
                    <tr><td colSpan={7} className="py-6 text-parchment/40 text-center">Nenhuma reserva para este dia.</td></tr>
                  ) : rows.map((r,i) => (
                    <tr key={i} className="border-b border-white/[0.08] hover:bg-white/[0.05] transition-colors">
                      <td className="py-2.5 font-medium">{r.nome}</td>
                      <td className="py-2.5 text-parchment/70">{r.telefone}</td>
                      <td className="py-2.5">{r.modalidade}</td>
                      <td className="py-2.5">{r.quadra}</td>
                      <td className="py-2.5">{r.horario}</td>
                      <td className="py-2.5"><span className="inline-block px-2 py-0.5 bg-emerald/20 text-emerald text-xs rounded-md font-medium">{r.status}</span></td>
                      <td className="py-2.5 font-display font-medium">{r.valor}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex flex-wrap gap-3 mt-6">
              <button onClick={handleDownload} className="inline-flex items-center gap-2 px-5 py-3 bg-amber text-graphite font-display font-semibold rounded-full hover:bg-amber-soft transition shadow-lg shadow-amber/20 text-sm"><Download size={16} /> Baixar CSV</button>
              <button onClick={handleSendEmail} className="inline-flex items-center gap-2 px-5 py-3 bg-parchment/10 text-parchment font-display font-medium rounded-full hover:bg-parchment/20 border border-parchment/15 transition text-sm"><Mail size={16} /> {sent ? 'Enviado!' : 'Enviar por e-mail'}</button>
              <a href="/whatsapp-guia.html" className="inline-flex items-center gap-2 px-5 py-3 bg-parchment/10 text-parchment font-display font-medium rounded-full hover:bg-parchment/20 border border-parchment/15 transition text-sm"><FileText size={16} /> Ver Guia WhatsApp</a>
            </div>
          </div>
        </div>

        <div className="bg-white/[0.05] border border-white/[0.08] rounded-3xl p-8 lg:p-10 mt-12">
          <h3 className="font-display text-2xl font-bold text-parchment mb-3">Como funciona o relatório automático</h3>
          <ul className="font-sans text-parchment/70 leading-relaxed space-y-2 list-none">
            <li>• O site registra reservas via <strong>WhatsApp 86994733462</strong> e <strong>Pix 06164531322</strong>.</li>
            <li>• O dono seleciona a data e vê todos os dados: nome, telefone, modalidade, quadra, horário, status.</li>
            <li>• Nenhum dado é oculto — tudo visível no relatório.</li>
            <li>• Baixa CSV ou envia por e-mail diretamente deste painel.</li>
            <li>• Equipe atende de <strong>Seg a Sex 08h às 18h</strong>. Funciona 24h via automação.</li>
          </ul>
        </div>
      </div>
    </section>
  );
}
