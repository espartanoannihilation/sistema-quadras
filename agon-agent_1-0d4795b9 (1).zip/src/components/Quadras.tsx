import { useState } from 'react';
import { Clock, MapPin, Star, CalendarDays } from 'lucide-react';

const quadras = [
  { title: 'Quadra A — Grama Sintética', sport: 'Futebol Society', price: 'R$ 120,00', time: '18h às 22h', rating: 4.9, img: 'https://images.unsplash.com/photo-1517466787929-bc90951d0974?q=80&w=800&auto=format&fit=crop' },
  { title: 'Quadra B — Piso Esportivo', sport: 'Vôlei', price: 'R$ 85,00', time: '17h às 23h', rating: 4.8, img: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=800&auto=format&fit=crop' },
  { title: 'Quadra C — Areia Fina', sport: 'Beach Tennis', price: 'R$ 95,00', time: '16h às 21h', rating: 4.7, img: 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=800&auto=format&fit=crop' },
  { title: 'Quadra D — Grama Natural', sport: 'Futebol Society', price: 'R$ 145,00', time: '06h às 23h', rating: 5.0, img: 'https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?q=80&w=800&auto=format&fit=crop' },
];

const horarios = [
  '06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00',
  '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00',
];

const dias = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

export default function Quadras() {
  const [dia, setDia] = useState('Ter');
  const [hora, setHora] = useState('18:00');
  const [enviado, setEnviado] = useState(false);

  const handleReserva = () => {
    setEnviado(true);
    setTimeout(() => setEnviado(false), 4000);
  };

  return (
    <section id="quadras" className="bg-surface py-24 lg:py-32">
      <div className="mx-auto max-w-6xl px-6 lg:px-10">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-graphite tracking-[-0.03em] mb-3">Reserve agora</h2>
          <p className="font-sans text-ink/60 text-lg">Escolha o dia, a hora e a quadra. Pronto.</p>
        </div>

        {/* Seletor de dia + hora */}
        <div className="bg-white rounded-3xl shadow-lg shadow-slate-200/60 border border-slate-100 p-6 lg:p-10 mb-12">
          <div className="flex flex-col lg:flex-row lg:items-end gap-6 lg:gap-10">
            <div className="flex-1">
              <label className="font-sans text-xs uppercase tracking-[0.15em] text-ink-soft mb-3 block">Dia da semana</label>
              <div className="flex gap-2 flex-wrap">
                {dias.map(d => (
                  <button key={d} onClick={() => setDia(d)} className={`px-4 py-2.5 rounded-xl font-display font-medium text-sm transition-all ${dia === d ? 'bg-graphite text-white shadow-md' : 'bg-surface text-ink hover:bg-slate-200'}`}>{d}</button>
                ))}
              </div>
            </div>
            <div className="flex-1">
              <label className="font-sans text-xs uppercase tracking-[0.15em] text-ink-soft mb-3 block">Horário</label>
              <div className="flex gap-2 flex-wrap">
                {horarios.map(h => (
                  <button key={h} onClick={() => setHora(h)} className={`px-3 py-2 rounded-xl font-sans text-sm transition-all ${hora === h ? 'bg-amber text-graphite font-semibold shadow-md' : 'bg-surface text-ink/70 hover:bg-slate-200'}`}>{h}</button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-8 flex items-center justify-between pt-6 border-t border-slate-100">
            <div className="flex items-center gap-3 text-sm font-sans text-ink-soft">
              <CalendarDays size={18} className="text-amber" />
              <span><strong className="text-graphite">{dia}</strong> às <strong className="text-graphite">{hora}</strong></span>
            </div>
            <button onClick={handleReserva} className="inline-flex items-center gap-2 bg-amber text-graphite font-display font-semibold px-6 py-3 rounded-full hover:bg-amber-soft transition-colors shadow-lg shadow-amber/20">
              Confirmar reserva <span>→</span>
            </button>
          </div>
          {enviado && <p className="font-sans text-sm text-emerald font-medium mt-4">Reserva confirmada! Você receberá a confirmação no WhatsApp.</p>}
        </div>

        {/* Cards das quadras */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {quadras.map((q) => (
            <article key={q.title} className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-300 border border-slate-100 hover:-translate-y-1">
              <div className="relative h-56 overflow-hidden">
                <img src={q.img} alt={q.title} loading="lazy" className="w-full h-full object-cover scale-105 group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute top-4 left-4 flex gap-2">
                  <span className="px-2.5 py-1 bg-graphite/80 text-white text-[11px] font-display font-semibold rounded-lg backdrop-blur-sm">{q.sport}</span>
                  <span className="px-2.5 py-1 bg-amber text-graphite text-[11px] font-display font-bold rounded-lg">{q.price}</span>
                </div>
              </div>
              <div className="p-7">
                <div className="flex items-center gap-2 mb-2 text-amber"><Star size={16} fill="currentColor" /><span className="font-display font-semibold text-sm">{q.rating}</span><span className="text-slate-300 text-xs">(128)</span></div>
                <h3 className="font-display text-2xl font-semibold text-graphite mb-3 tracking-tight">{q.title}</h3>
                <div className="flex items-center gap-5 text-sm text-ink/60 font-sans mb-5">
                  <span className="flex items-center gap-1.5"><Clock size={14} /> {q.time}</span>
                  <span className="flex items-center gap-1.5"><MapPin size={14} /> Centro</span>
                </div>
                <a href="https://wa.me/5586994733462?text=RESERVA+AUTOMATICA+Quadra+{q.title}" target="_blank" rel="noopener noreferrer" className="block text-center font-display font-medium text-sm bg-amber text-graphite px-5 py-2.5 rounded-full hover:bg-amber-soft transition-colors shadow-md">Marcar agora</a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
