import { useState, useRef, useEffect } from 'react';
import { Send, Phone, Clock, MapPin, CreditCard, Shield, CheckCircle2, MessageCircle, Wrench } from 'lucide-react';
import { DADOS_ESPACO, reservasAtivas, reservasCanceladas, verificarDisponibilidade } from '../lib/space';

type Step = 'boasvindas' | 'modalidade' | 'datahora' | 'disponibilidade' | 'dados' | 'confirmar' | 'finalizar' | 'cancelar' | 'reagendar';

export default function Assistant() {
  const [step, setStep] = useState<Step>('boasvindas');
  const [msg, setMsg] = useState('');
  const [chat, setChat] = useState<{from:'user'|'bot';text:string}[]>([]);
  const chatEnd = useRef<HTMLDivElement>(null);

  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [modalidade, setModalidade] = useState<'vôlei'|'beach tennis'>('vôlei');
  const [data, setData] = useState('');
  const [horaInicio, setHoraInicio] = useState('');
  const [horaFim, setHoraFim] = useState('');
  const [quadraPref, setQuadraPref] = useState('');

  const [cancelNome, setCancelNome] = useState('');
  const [cancelData, setCancelData] = useState('');
  const [cancelHora, setCancelHora] = useState('');
  const [cancelMotivo, setCancelMotivo] = useState('');

  const scrollToBottom = () => setTimeout(() => chatEnd.current?.scrollIntoView({behavior:'smooth'}), 50);

  const bot = (text: string, action?: () => void) => {
    setChat(prev => [...prev, {from:'bot',text}]);
    scrollToBottom();
    if (action) setTimeout(action, 700);
  };

  const user = (text: string) => {
    setChat(prev => [...prev, {from:'user',text}]);
    scrollToBottom();
  };

  // Início
  useEffect(() => {
    bot(`Olá! Sou o assistente virtual da ${DADOS_ESPACO.nome}. Como posso ajudar?\n\n• Reservar quadra\n• Ver disponibilidade\n• Cancelar ou reagendar\n• Dúvidas sobre preços, regras, endereço`);
    bot(`Estamos em ${DADOS_ESPACO.endereco} — ${DADOS_ESPACO.horario}. Atendimento humano: ${DADOS_ESPACO.atendimento}.`);
  }, []);

  const handleSend = () => {
    const t = msg.trim();
    if (!t) return;
    user(t);
    setMsg('');

    // Identificar intenção
    const lower = t.toLowerCase();
    if (lower.includes('reservar') || lower.includes('marcar') || lower.includes('agendar')) {
      bot('Perfeito! Vamos reservar. Qual modalidade deseja?', () => setStep('modalidade'));
      return;
    }
    if (lower.includes('disponibil') || lower.includes('horário') || lower.includes('livre')) {
      bot('Vou verificar a agenda. Qual dia e horário você quer?', () => setStep('datahora'));
      return;
    }
    if (lower.includes('cancelar') || lower.includes('cancelamento')) {
      bot('Entendi. Preciso do nome e do horário da reserva. Qual o motivo?', () => setStep('cancelar'));
      return;
    }
    if (lower.includes('reagendar') || lower.includes('mudar')) {
      bot('Para reagendar, me informe o nome, o horário atual e o novo desejado.', () => setStep('reagendar'));
      return;
    }
    if (lower.includes('preço') || lower.includes('valor') || lower.includes('custa')) {
      bot(`Valores: Vôlei R$ 85/h | Beach Tennis R$ 120/h | Promoção matinal (06h-12h) R$ 65/h. Pagamento: ${DADOS_ESPACO.pagamento}.`);
      return;
    }
    if (lower.includes('endereço') || lower.includes('local') || lower.includes('onde')) {
      bot(`Endereço: ${DADOS_ESPACO.endereco}. Estacionamento gratuito para clientes com reserva confirmada.`);
      return;
    }
    if (lower.includes('regras') || lower.includes('regra')) {
      bot(`Regras do espaço:\n• Uso exclusivo no horário reservado\n• Sem bebidas alcoólicas nas quadras\n• Sapatilhas obrigatórias no piso esportivo\n• Estacionamento grátis com reserva confirmada\n• Aulas/eventos: agendar com 48h de antecedência`);
      return;
    }
    if (lower.includes('contato') || lower.includes('falar') || lower.includes('pessoa')) {
      bot(`Fale direto pelo WhatsApp: ${DADOS_ESPACO.whatsapp}. Atendimento humano: ${DADOS_ESPACO.contato_equipe}. Equipe atende de ${DADOS_ESPACO.atendimento}.`);
      return;
    }
    bot('Não entendi totalmente — posso ajudar com reserva, disponibilidade, cancelamento ou informações do espaço. O que precisa?');
  };

  // Passo modalidade
  const escolherModalidade = (m: 'vôlei' | 'beach tennis') => {
    setModalidade(m);
    user(`Quero reservar ${m}`);
    bot(`Excelente — ${m}. Qual data e horário? (ex: Terça, 18h)`, () => setStep('datahora'));
  };

  // Passo data/hora
  const confirmarDataHora = () => {
    if (!data || !horaInicio) return bot('Preciso da data e do horário para verificar. Pode repetir?', () => { setStep('datahora'); });
    // Se data for passada
    const hoje = new Date();
    const selecionada = new Date(data);
    if (selecionada < new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate())) {
      bot('Não posso agendar em data passada. Escolha uma data futura, por favor.', () => { setStep('datahora'); });
      return;
    }
    user(`Data: ${data} | Início: ${horaInicio} | Fim: ${horaFim || '1h após'}`);

    // Verificar disponibilidade simples
    const quadraSugerida = quadraPref || (modalidade === 'beach tennis' ? 'Quadra 1 — Areia Fina' : 'Quadra 3 — Piso Esportivo');
    const disponivel = verificarDisponibilidade(quadraSugerida, data, horaInicio, horaFim || horaInicio + ':00');

    if (disponivel) {
      bot(`Horário livre na ${quadraSugerida}! Vou coletar seus dados para confirmar. Qual seu nome completo?`, () => setStep('dados'));
    } else {
      bot(`Esse horário parece ocupado na ${quadraSugerida}. Sugeridos próximos:\n• 17h na mesma quadra\n• 19h na mesma\n• Outro dia? Qual?`, () => setStep('datahora'));
    }
  };

  // Passo dados
  const finalizarReserva = () => {
    if (!nome.trim() || !telefone.trim()) return bot('Preciso confirmar nome completo e telefone com DDD antes de finalizar. Pode preencher?', () => { setStep('dados'); });
    if (telefone.trim().length < 10) return bot('Telefone parece incompleto. Preciso do DDD e número completo.', () => { setStep('dados'); });
    user(`Nome: ${nome.trim()} | Telefone: ${telefone.trim()}`);

    const inicio = horaInicio || '18:00';
    const fim = horaFim || '19:00';
    const quadra = quadraPref || (modalidade === 'beach tennis' ? 'Quadra 1 — Areia Fina (Beach Tennis)' : 'Quadra 3 — Piso Esportivo (Vôlei)');
    const valor = modalidade === 'beach tennis' ? 'R$ 120,00' : 'R$ 85,00';

    bot(`Reserva Confirmada! ✅\n\nNome: ${nome.trim()}\nTelefone: ${telefone.trim()}\nModalidade: ${modalidade}\nQuadra: ${quadra}\nData: ${data}\nHorário: ${inicio} às ${fim}\nValor: ${valor}\nStatus: Confirmada\n\nWhatsApp: ${DADOS_ESPACO.whatsapp}\nPix chave: 06164531322`);

    // Salvar
    const r = { nome: nome.trim(), telefone: telefone.trim(), modalidade, data, inicio, fim, quadra, status: 'Confirmada' as const };
    // Evita duplicar mesma quadra/hora/data
    const jaExiste = reservasAtivas.find(r => r.nome === nome.trim() && r.data === data && r.inicio === horaInicio && r.quadra === (quadraPref || quadra));
    if (jaExiste) {
      bot(`Já existe uma reserva com esses dados (${nome.trim()} — ${data} ${horaInicio}). Se quiser reagendar, me avise.`);
      return;
    }
    reservasAtivas.push(r);
    setStep('finalizar');
  };

  const cancelarReserva = () => {
    if (!cancelNome.trim() || !cancelData.trim() || !cancelHora.trim()) return bot('Preciso do nome, data e horário para localizar a reserva. Pode repetir?', () => setStep('cancelar'));
    user(`Cancelamento: ${cancelNome.trim()} | ${cancelData.trim()} ${cancelHora.trim()} | Motivo: ${cancelMotivo.trim() || 'Não informado'}`);
    reservasCanceladas.push({ nome: cancelNome, telefone: '', modalidade: 'vôlei', data: cancelData, inicio: cancelHora, fim: cancelHora, quadra: 'N/A', status: 'Cancelada', motivoCancelamento: cancelMotivo });
    bot(`Reserva Cancelada\nNome: ${cancelNome}\nQuadra: (consultado)\nData: ${cancelData}\nHorário: ${cancelHora}\nMotivo: ${cancelMotivo || 'Não informado'}\nStatus: Cancelada\n\nSe quiser reagendar, me avise.`);
    setCancelNome(''); setCancelData(''); setCancelHora(''); setCancelMotivo('');
  };

  const reagendarReserva = () => {
    bot('Para reagendar, me informe:\n1. Nome do cliente\n2. Horário atual da reserva\n3. Novo dia/hora desejado\nVou verificar disponibilidade e confirmar.');
  };

  return (
    <section id="assistente" className="relative bg-gradient-to-b from-parchment via-cream to-parchment py-24 lg:py-28">
      <div className="mx-auto max-w-[720px] px-6 lg:px-10">
        <div className="text-center mb-10">
          <span className="inline-flex items-center gap-2 bg-ink/5 text-ink-soft px-3 py-1 rounded-full text-xs font-display font-semibold tracking-wide mb-3">
            <MessageCircle size={14} /> Assistente Virtual — 24h
          </span>
          <h2 className="font-display text-4xl lg:text-5xl font-bold text-ink tracking-[-0.03em]">Fale com o assistente</h2>
          <p className="font-sans text-ink-soft mt-3">Reserva, disponibilidade, cancelamento, reagendamento.</p>
        </div>

        <div className="bg-white rounded-[2rem] shadow-xl shadow-ink/[0.06] border border-ink/[0.06] overflow-hidden">
          {/* Chat */}
          <div className="h-[420px] overflow-y-auto p-6 space-y-4 bg-gradient-to-b from-white to-parchment/50">
            {chat.map((c, i) => (
              <div key={i} className={`flex ${c.from === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] px-5 py-3.5 rounded-2xl text-[15px] leading-relaxed font-sans ${c.from === 'user' ? 'bg-ink text-parchment rounded-br-md' : 'bg-cream text-ink border border-ink/[0.08] rounded-bl-md shadow-sm'}`}>
                  <div className="whitespace-pre-line">{c.text}</div>
                </div>
              </div>
            ))}
            <div ref={chatEnd} />
          </div>

          {/* Controles interativos */}
          <div className="p-5 border-t border-ink/[0.07] bg-cream/60 space-y-4">
            {/* Passo modalidade */}
            {step === 'modalidade' && (
              <div className="flex gap-3 flex-wrap">
                <button onClick={() => escolherModalidade('vôlei')} className="px-5 py-2.5 bg-ink text-parchment font-display font-medium rounded-xl hover:bg-ink-soft transition">Vôlei</button>
                <button onClick={() => escolherModalidade('beach tennis')} className="px-5 py-2.5 bg-ink text-parchment font-display font-medium rounded-xl hover:bg-ink-soft transition">Beach Tennis</button>
              </div>
            )}

            {/* Passo data/hora */}
            {step === 'datahora' && (
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-sans text-xs uppercase tracking-widest text-ink-soft mb-1 block">Data</label>
                  <input type="date" value={data} onChange={e => setData(e.target.value)} className="w-full bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm focus:outline-none focus:border-amber/60" />
                </div>
                <div>
                  <label className="font-sans text-xs uppercase tracking-widest text-ink-soft mb-1 block">Início</label>
                  <input type="time" value={horaInicio} onChange={e => setHoraInicio(e.target.value)} className="w-full bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm focus:outline-none focus:border-amber/60" />
                </div>
                <div className="sm:col-span-2 flex gap-3">
                  <button onClick={confirmarDataHora} className="flex-1 py-3 bg-ink text-parchment font-display font-medium rounded-xl hover:bg-ink-soft transition">Verificar disponibilidade</button>
                  <button onClick={() => setStep('boasvindas')} className="px-5 py-3 bg-ink/5 text-ink font-medium rounded-xl hover:bg-ink/10 transition">Voltar</button>
                </div>
                <div className="sm:col-span-2 text-xs text-ink-soft font-sans">Quadra preferida: <button onClick={() => setQuadraPref('Quadra 3 — Piso Esportivo')} className="underline text-ink">Vôlei</button> ou <button onClick={() => setQuadraPref('Quadra 1 — Areia Fina')} className="underline text-ink">Beach Tennis</button></div>
              </div>
            )}

            {/* Passo dados */}
            {step === 'dados' && (
              <div className="grid sm:grid-cols-2 gap-3">
                <input placeholder="Nome completo" value={nome} onChange={e => setNome(e.target.value)} className="bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm focus:outline-none focus:border-amber/60" />
                <input placeholder="Telefone com DDD" value={telefone} onChange={e => setTelefone(e.target.value)} className="bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm focus:outline-none focus:border-amber/60" />
                <button onClick={finalizarReserva} className="sm:col-span-2 py-3 bg-amber text-graphite font-display font-bold rounded-xl hover:bg-amber-soft transition shadow-lg shadow-amber/20">Confirmar Reserva</button>
              </div>
            )}

            {/* Cancelar */}
            {step === 'cancelar' && (
              <div className="grid sm:grid-cols-2 gap-3">
                <input placeholder="Nome da reserva" value={cancelNome} onChange={e => setCancelNome(e.target.value)} className="bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm" />
                <input placeholder="Data (ex: 25/07)" value={cancelData} onChange={e => setCancelData(e.target.value)} className="bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm" />
                <input placeholder="Horário (ex: 18h)" value={cancelHora} onChange={e => setCancelHora(e.target.value)} className="bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm" />
                <input placeholder="Motivo (opcional)" value={cancelMotivo} onChange={e => setCancelMotivo(e.target.value)} className="bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm" />
                <button onClick={cancelarReserva} className="sm:col-span-2 py-3 bg-ink text-parchment font-display font-bold rounded-xl hover:bg-ink-soft transition">Confirmar Cancelamento</button>
              </div>
            )}

            {/* Reagendar */}
            {step === 'reagendar' && (
              <div className="grid sm:grid-cols-2 gap-3">
                <input placeholder="Nome do cliente" className="bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm" />
                <input placeholder="Horário atual (ex: Ter 18h)" className="bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm" />
                <input placeholder="Novo dia/hora desejado" className="bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm" />
                <button onClick={reagendarReserva} className="sm:col-span-2 py-3 bg-amber text-graphite font-display font-bold rounded-xl hover:bg-amber-soft transition">Verificar e Reagendar</button>
              </div>
            )}

            {/* Final / Voltar */}
            {step === 'finalizar' && (
              <div className="flex gap-3">
                <button onClick={() => setStep('boasvindas')} className="flex-1 py-3 bg-ink text-parchment font-display font-medium rounded-xl hover:bg-ink-soft transition">Nova reserva</button>
                <a href="#contacto" className="flex-1 py-3 bg-amber text-graphite font-display font-medium rounded-xl text-center hover:bg-amber-soft transition">Falar com equipe</a>
              </div>
            )}

            {/* Input de texto livre */}
            <div className="flex gap-2 pt-2 border-t border-ink/[0.07]">
              <input value={msg} onChange={e => setMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} placeholder="Escreva: reservar, disponibilidade, cancelar, reagendar..." className="flex-1 bg-white border border-ink/10 rounded-xl px-4 py-3 font-sans text-sm focus:outline-none focus:border-amber/60" />
              <button onClick={handleSend} aria-label="Enviar" className="w-11 h-11 rounded-xl bg-ink text-parchment flex items-center justify-center hover:bg-ink-soft transition shadow-lg shadow-ink/10"><Send size={18} /></button>
            </div>

            <div className="flex flex-wrap gap-2 pt-1">
              <button onClick={() => { setStep('modalidade'); bot('Vamos reservar! Qual modalidade?') }} className="text-xs font-sans bg-ink/[0.05] text-ink px-2.5 py-1 rounded-full hover:bg-ink/10">Reservar</button>
              <button onClick={() => { setStep('datahora'); bot('Qual dia e horário você quer verificar?') }} className="text-xs font-sans bg-ink/[0.05] text-ink px-2.5 py-1 rounded-full hover:bg-ink/10">Disponibilidade</button>
              <button onClick={() => { setStep('cancelar'); bot('Para cancelar, qual o nome e horário?') }} className="text-xs font-sans bg-ink/[0.05] text-ink px-2.5 py-1 rounded-full hover:bg-ink/10">Cancelar</button>
              <button onClick={() => { setStep('reagendar'); bot('Para reagendar, qual o nome e novo horário?') }} className="text-xs font-sans bg-ink/[0.05] text-ink px-2.5 py-1 rounded-full hover:bg-ink/10">Reagendar</button>
              <button onClick={() => bot(`Endereço: ${DADOS_ESPACO.endereco}. Horário: ${DADOS_ESPACO.horario}. Estacionamento: grátis com reserva.`)} className="text-xs font-sans bg-ink/[0.05] text-ink px-2.5 py-1 rounded-full hover:bg-ink/10">Info / Preços</button>
            </div>
          </div>
        </div>

        <div className="mt-8 grid sm:grid-cols-4 gap-4 text-center">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-ink/[0.06]">
            <MapPin size={22} className="text-amber mx-auto mb-2" />
            <p className="font-display font-semibold text-sm">${DADOS_ESPACO.endereco}</p>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-ink/[0.06]">
            <Clock size={22} className="text-amber mx-auto mb-2" />
            <p className="font-sans text-xs text-ink-soft">${DADOS_ESPACO.horario}</p>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-ink/[0.06]">
            <CreditCard size={22} className="text-amber mx-auto mb-2" />
            <p className="font-sans text-xs text-ink-soft">${DADOS_ESPACO.pagamento}</p>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-ink/[0.06]">
            <Wrench size={22} className="text-amber mx-auto mb-2" />
            <p className="font-sans text-xs text-ink-soft">${DADOS_ESPACO.atendimento}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
