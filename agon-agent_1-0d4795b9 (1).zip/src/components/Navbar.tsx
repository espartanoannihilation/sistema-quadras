import { useState } from 'react';
import { Menu, X, MapPin, Phone } from 'lucide-react';

export default function Navbar() {
  const [open, setOpen] = useState(false);

  const links = [
    { label: 'Como funciona', href: '#como-funciona' },
    { label: 'Quadras', href: '#quadras' },
    { label: 'Preços', href: '#precos' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
      <div className="mx-auto max-w-6xl px-6 lg:px-10 h-[72px] flex items-center justify-between">
        <a href="#" className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-lg bg-graphite flex items-center justify-center shadow-md shadow-slate-900/10 group-hover:scale-105 transition-transform">
            <MapPin size={18} className="text-amber" />
          </div>
          <div className="leading-none">
            <span className="font-display text-xl font-bold text-graphite tracking-tight block">Arena</span>
            <span className="font-sans text-[10px] font-semibold text-amber uppercase tracking-[0.15em]">Manager</span>
          </div>
        </a>

        <div className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="font-sans text-sm font-medium text-ink/70 hover:text-graphite transition-colors">{l.label}</a>
          ))}
          <a href="#contato" className="font-display font-medium text-sm bg-graphite text-white px-5 py-2.5 rounded-full hover:bg-ink transition-colors shadow-lg shadow-graphite/15">Reservar</a>
          <a href="https://wa.me/5586994733462" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-display font-medium text-sm bg-amber text-graphite px-5 py-2.5 rounded-full hover:bg-amber-soft transition-colors shadow-lg shadow-amber/15">WhatsApp <Phone size={13} /></a>
        </div>

        <button onClick={() => setOpen(!open)} className="md:hidden p-2 text-graphite" aria-label="Menu">{open ? <X size={22} /> : <Menu size={22} />}</button>
      </div>

      <div className={`md:hidden overflow-hidden transition-all duration-300 ease-[cubic-bezier(.22,1,.36,1)] ${open ? 'max-h-80 opacity-100' : 'max-h-0 opacity-0'}`}>
        <div className="px-6 pb-8 pt-2 flex flex-col gap-3 bg-white/95 backdrop-blur-2xl border-t border-slate-100">
          {links.map((l) => <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="font-sans text-base font-medium text-ink py-2">{l.label}</a>)}
          <a href="#contato" onClick={() => setOpen(false)} className="mt-2 text-center font-display font-medium bg-graphite text-white px-5 py-3 rounded-full">Reservar agora</a>
        </div>
      </div>
    </nav>
  );
}
