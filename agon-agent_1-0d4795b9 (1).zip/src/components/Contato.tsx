import { useState } from 'react';
import { Send, MapPin, Mail, Phone } from 'lucide-react';

export default function Contato() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ nome: '', whatsapp: '', mensagem: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 5000);
    setForm({ nome: '', whatsapp: '', mensagem: '' });
  };

  return (
    <section id="contato" className="bg-gradient-to-b from-graphite to-[#0b1220] text-white py-24 lg:py-32">
      <div className="mx-auto max-w-6xl px-6 lg:px-10">
        <div className="grid lg:grid-cols-2 gap-14 lg:gap-24 items-start">
          <div>
            <h2 className="font-display text-4xl lg:text-5xl font-bold tracking-[-0.03em] mb-5">Fale com a gente</h2>
            <p className="font-sans text-slate-300 text-lg leading-relaxed mb-10">Quer reservar uma quadra, fechar um pacote mensal ou tirar dúvidas? Preencha o formulário ou entre em contato direto.</p>

            <div className="space-y-6">
              <a href="#" className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-amber group-hover:bg-amber/10 transition-colors"><MapPin size={20} /></div>
                <div><p className="font-sans text-xs text-slate-400 uppercase tracking-widest">Endereço</p><p className="font-display font-medium">Av. das Quadras, 1200 — Centro</p></div>
              </a>
              <a href="#" className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-amber group-hover:bg-amber/10 transition-colors"><Mail size={20} /></div>
                <div><p className="font-sans text-xs text-slate-400 uppercase tracking-widest">E-mail</p><p className="font-display font-medium">reservas@arenamanager.com.br</p></div>
              </a>
              <a href="https://wa.me/5586994733462" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-amber group-hover:bg-amber/10 transition-colors"><Phone size={20} /></div>
                <div><p className="font-sans text-xs text-slate-400 uppercase tracking-widest">WhatsApp Suporte</p><p className="font-display font-medium">(86) 99473-3462</p></div>
              </a>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="bg-white/[0.04] border border-white/[0.08] rounded-3xl p-8 lg:p-10 backdrop-blur-sm">
            <div className="grid sm:grid-cols-2 gap-5 mb-5">
              <div>
                <label htmlFor="nome" className="font-sans text-xs uppercase tracking-widest text-slate-400 mb-2 block">Nome</label>
                <input id="nome" required value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} placeholder="Seu nome" className="w-full bg-white/[0.06] border border-white/10 rounded-xl px-4 py-3 font-sans text-sm placeholder:text-slate-500 focus:outline-none focus:border-amber focus:ring-2 focus:ring-amber/10 transition-all" />
              </div>
              <div>
                <label htmlFor="whatsapp" className="font-sans text-xs uppercase tracking-widest text-slate-400 mb-2 block">WhatsApp</label>
                <input id="whatsapp" required value={form.whatsapp} onChange={e => setForm({ ...form, whatsapp: e.target.value })} placeholder="(11) 99999-9999" className="w-full bg-white/[0.06] border border-white/10 rounded-xl px-4 py-3 font-sans text-sm placeholder:text-slate-500 focus:outline-none focus:border-amber focus:ring-2 focus:ring-amber/10 transition-all" />
              </div>
            </div>
            <div className="mb-6">
              <label htmlFor="mensagem" className="font-sans text-xs uppercase tracking-widest text-slate-400 mb-2 block">Mensagem</label>
              <textarea id="mensagem" required rows={4} value={form.mensagem} onChange={e => setForm({ ...form, mensagem: e.target.value })} placeholder="Qual quadra e horário você deseja?" className="w-full bg-white/[0.06] border border-white/10 rounded-xl px-4 py-3 font-sans text-sm placeholder:text-slate-500 focus:outline-none focus:border-amber focus:ring-2 focus:ring-amber/10 transition-all resize-none" />
            </div>
            <div className="flex items-center justify-between gap-4">
              <div className="flex gap-3">
                <a href="https://wa.me/5586994733462?text=Suporte:+Preciso+de+ajuda+Arena+Manager" target="_blank" rel="noopener noreferrer" className="flex-1 text-center font-display font-medium bg-green-600 text-white px-5 py-3.5 rounded-full hover:bg-green-700 transition-colors shadow-lg shadow-green-600/20">Suporte WhatsApp</a>
                <a href="https://wa.me/5586994733462?text=Automatizado:+Quero+reservar+em+%7Bdia%7D+%7Bhora%7D" target="_blank" rel="noopener noreferrer" className="flex-1 text-center font-display font-medium bg-amber text-graphite px-5 py-3.5 rounded-full hover:bg-amber-soft transition-colors shadow-lg shadow-amber/20">Reserva Auto</a>
                <button type="submit" className="flex-1 font-display font-medium bg-graphite text-white px-5 py-3.5 rounded-full hover:bg-ink transition-colors">Formulário</button>
              </div>
              {sent && <span className="font-sans text-sm text-amber font-medium">Solicitação enviada!</span>}
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
