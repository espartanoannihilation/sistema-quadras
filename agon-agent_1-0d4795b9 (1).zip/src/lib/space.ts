export const DADOS_ESPACO = {
  nome: "Arena Sport Teresina",
  endereco: "Av. Joaquim Nabuco, 1450 — Jardim Aurora, Teresina-PI",
  horario: "Seg a Sex: 05h às 23h | Sáb e Dom: 06h às 22h",
  quadras: [
    "Quadra 1 — Areia Fina (Beach Tennis)",
    "Quadra 2 — Areia Fina (Beach Tennis)",
    "Quadra 3 — Piso Esportivo (Vôlei)",
    "Quadra 4 — Grama Sintética (Vôlei / Futevôlei)"
  ],
  precos: {
    volei: "R$ 85,00 / hora",
    beach_tennis: "R$ 120,00 / hora",
    volei_matutino: "R$ 65,00 / hora (promoção 06h-12h)"
  },
  pagamento: "PIX (chave: 06164531322) | Dinheiro | Cartão (no balcão)",
  cancelamento: "Até 12h antes sem taxa. Entre 12h e 2h: 50%. Menos de 2h: não reembolsável.",
  regras: [
    "Uso exclusivo durante o horário reservado.",
    "Proibido consumo de bebida alcoólica nas quadras.",
    "Uso de sapatilhas apropriadas é obrigatório no piso esportivo.",
    "Estacionamento gratuito para clientes com reserva confirmada.",
    "Aulas e eventos devem ser agendados com antecedência mínima de 48h."
  ],
  contato_equipe: "WhatsApp 86994733452 | Atendimento humano: Seg a Sex 08h às 18h | E-mail: reservas@arenasportpi.com.br",
  atendimento: "Funciona 24h (automação). Equipe humana: Seg a Sex 08h-18h, Sáb 09h-13h.",
  whatsapp: "https://wa.me/5586994733462"
};

export type Modalidade = "vôlei" | "beach tennis";
export interface Reserva {
  nome: string;
  telefone: string;
  modalidade: Modalidade;
  data: string;
  inicio: string;
  fim: string;
  quadra: string;
  status: "Confirmada" | "Cancelada" | "Reagendada";
  motivoCancelamento?: string;
}

export const reservasAtivas: Reserva[] = [];
export const reservasCanceladas: Reserva[] = [];

export function verificarDisponibilidade(quadra: string, data: string, inicio: string, fim: string): boolean {
  return !reservasAtivas.some(r =>
    r.quadra === quadra && r.data === data &&
    !(r.fim <= inicio || r.inicio >= fim)
  );
}

export interface ReportRow{data:string;nome:string;telefone:string;modalidade:string;quadra:string;horario:string;status:string;valor:string}
export function gerarRelatorioDiario(data:string):ReportRow[]{return reservasAtivas.filter(r=>r.data===data).map(r=>({data:r.data,nome:r.nome,telefone:r.telefone,modalidade:r.modalidade,quadra:r.quadra,horario:r.inicio+" - "+r.fim,status:r.status,valor:r.modalidade==="beach tennis"?"R$ 120,00":"R$ 85,00"}))}
export function relatorioParaCSV(data: string): string {
  const linhas = gerarRelatorioDiario(data);
  const cabec = 'Data,Nome,Telefone,Modalidade,Quadra,Horario,Status,Valor';
  const corpo = linhas.map(l => `${l.data},"${l.nome}",${l.telefone},${l.modalidade},${l.quadra},${l.horario},${l.status},${l.valor}`).join('\n');
  return cabec + '\n' + (corpo || 'Nenhuma reserva');
}
