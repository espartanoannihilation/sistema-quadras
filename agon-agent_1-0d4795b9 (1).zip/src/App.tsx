import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ComoFunciona from './components/ComoFunciona';
import Quadras from './components/Quadras';
import Precos from './components/Precos';
import Contato from './components/Contato';
import Assistant from './components/Assistant';
import DonoPanel from './components/DonoPanel';
import AdminDashboard from './components/AdminDashboard';
import DailyReport from './components/DailyReport';

function Footer() {
  return (
    <footer className="bg-graphite border-t border-white/10 text-slate-400">
      <div className="mx-auto max-w-6xl px-6 lg:px-10 py-12 flex flex-col md:flex-row md:items-center md:justify-between gap-4 font-sans text-sm">
        <div className="flex items-center gap-2"><span className="font-display font-bold text-white text-xl">Arena</span><span className="font-display font-bold text-amber text-xl">Manager</span></div>
        <p>© {new Date().getFullYear()} Arena Manager. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
}

function App() {
  return (
    <div className="min-h-screen bg-surface text-ink font-sans">
      <Navbar />
      <main>
        <Hero />
        <ComoFunciona />
        <Quadras />
        <Precos />
        <Contato />
        <Assistant />
        <DonoPanel />
      </main>
      <Footer />
    </div>
  );
}

// PÁGINA DIRETA — NADA ESCONDIDO
export function ReservaDiretaPage() {
  return (
    <div className="min-h-screen bg-parchment">
      <div className="bg-graphite text-white text-center py-4 text-sm font-sans">WhatsApp: 86994733462 | Pix: 06164531322 | Nenhum dado oculto</div>
      <main>
        <iframe src="/reserva-direta.html" title="Reserva Direta" style={{width:'100%',height:'100vh',border:'none',display:'block'}} />
      </main>
    </div>
  );
}

export default App;
